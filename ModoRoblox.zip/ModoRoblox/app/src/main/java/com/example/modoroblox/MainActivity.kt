package com.example.modoroblox

import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val robloxPkg = "com.roblox.client"
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply {
            text = "Pronto. Toque para ativar."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val ativar = Button(this).apply {
            text = "🎮 Ativar Modo Roblox"
            setOnClickListener { ativarModo() }
        }
        val desativar = Button(this).apply {
            text = "Desativar (voltar ao normal)"
            setOnClickListener { desativarModo() }
        }
        root.addView(status)
        root.addView(ativar)
        root.addView(desativar)
        setContentView(root)
    }

    private fun ativarModo() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // 1) Não perturbe (precisa de permissão uma única vez)
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "Permita o acesso ao Não Perturbe e volte.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)

        // 2) Encerra apps em segundo plano (exceto sistema, este app e o Roblox)
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var count = 0
        for (app in packageManager.getInstalledApplications(0)) {
            val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem || app.packageName == packageName || app.packageName == robloxPkg) continue
            am.killBackgroundProcesses(app.packageName)
            count++
        }

        // 2b) Mantém a tela ligada
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        status.text = "Modo Roblox ativo.\n$count apps encerrados em segundo plano,\nNão Perturbe ligado."

        // 3) Abre o Roblox
        val launch = packageManager.getLaunchIntentForPackage(robloxPkg)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Roblox não está instalado.", Toast.LENGTH_LONG).show()
    }

    private fun desativarModo() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status.text = "Modo normal restaurado."
    }
}
